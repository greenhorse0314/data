The following files were generated for 'hbint2' in directory
/home/matt/fpgadev/usrp3/top/b250/coregen_dsp/

Opens the IP Customization GUI:
   Allows the user to customize or recustomize the IP instance.

   * hbint2.mif
   * hbint2_reload_order.txt

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * hbint2.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * hbint2.ngc
   * hbint2.v
   * hbint2.veo
   * hbint2COEFF_auto0_0.mif
   * hbint2COEFF_auto0_1.mif
   * hbint2COEFF_auto0_2.mif
   * hbint2COEFF_auto_HALFBAND_CENTRE0.mif
   * hbint2_reload_addrfilt_decode_rom.mif
   * hbint2filt_decode_rom.mif

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * hbint2.veo

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * hbint2.asy
   * hbint2.mif
   * hbint2_reload_order.txt

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * hbint2_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * hbint2.gise
   * hbint2.xise

Deliver Readme:
   Readme file for the IP.

   * hbint2_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * hbint2_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

