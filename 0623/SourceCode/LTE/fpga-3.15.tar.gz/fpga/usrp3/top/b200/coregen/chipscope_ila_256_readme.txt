The following files were generated for 'chipscope_ila_256' in directory
/home/ianb/fpgapriv_usrp3/fpgapriv/usrp3/top/b200/coregen/

ISE file generator:
   Add description here...

   * chipscope_ila_32_flist.txt

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * chipscope_ila_256.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * chipscope_ila_256.cdc
   * chipscope_ila_256.constraints/chipscope_ila_256.ucf
   * chipscope_ila_256.constraints/chipscope_ila_256.xdc
   * chipscope_ila_256.ncf
   * chipscope_ila_256.ngc
   * chipscope_ila_256.ucf
   * chipscope_ila_256.v
   * chipscope_ila_256.veo
   * chipscope_ila_256.xdc
   * chipscope_ila_256_xmdf.tcl

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * chipscope_ila_256.asy

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * chipscope_ila_256.gise
   * chipscope_ila_256.xise

Deliver Readme:
   Readme file for the IP.

   * chipscope_ila_256_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * chipscope_ila_256_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

