The following files were generated for 'b200_chipscope_ila' in directory
/home/bhilburn/code/ettus/b200_dev/fpgapriv.git/usrp3/top/b200/coregen/

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * b200_chipscope_ila.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * b200_chipscope_ila.cdc
   * b200_chipscope_ila.constraints/b200_chipscope_ila.ucf
   * b200_chipscope_ila.constraints/b200_chipscope_ila.xdc
   * b200_chipscope_ila.ncf
   * b200_chipscope_ila.ngc
   * b200_chipscope_ila.ucf
   * b200_chipscope_ila.v
   * b200_chipscope_ila.veo
   * b200_chipscope_ila.xdc
   * b200_chipscope_ila_xmdf.tcl

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * b200_chipscope_ila.asy

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * b200_chipscope_ila.gise
   * b200_chipscope_ila.xise

Deliver Readme:
   Readme file for the IP.

   * b200_chipscope_ila_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * b200_chipscope_ila_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

