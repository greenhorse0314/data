The following files were generated for 'b200_chipscope_icon' in directory
/home/bhilburn/xilinx/

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * b200_chipscope_icon.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * b200_chipscope_icon.constraints/b200_chipscope_icon.ucf
   * b200_chipscope_icon.constraints/b200_chipscope_icon.xdc
   * b200_chipscope_icon.ngc
   * b200_chipscope_icon.ucf
   * b200_chipscope_icon.v
   * b200_chipscope_icon.veo
   * b200_chipscope_icon.xdc
   * b200_chipscope_icon_xmdf.tcl

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * b200_chipscope_icon.asy

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * b200_chipscope_icon.gise
   * b200_chipscope_icon.xise

Deliver Readme:
   Readme file for the IP.

   * b200_chipscope_icon_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * b200_chipscope_icon_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

