The following files were generated for 'chipscope_ila_128' in directory
/home/ianb/fpgadev/usrp3/top/b200/coregen/

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * chipscope_ila_128.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * chipscope_ila_128.cdc
   * chipscope_ila_128.constraints/chipscope_ila_128.ucf
   * chipscope_ila_128.constraints/chipscope_ila_128.xdc
   * chipscope_ila_128.ncf
   * chipscope_ila_128.ngc
   * chipscope_ila_128.ucf
   * chipscope_ila_128.v
   * chipscope_ila_128.veo
   * chipscope_ila_128.xdc
   * chipscope_ila_128_xmdf.tcl

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * chipscope_ila_128.asy

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * chipscope_ila_128.gise
   * chipscope_ila_128.xise

Deliver Readme:
   Readme file for the IP.

   * chipscope_ila_128_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * chipscope_ila_128_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

