Timing closure of the CPLD design relies on the pre-set seed value. The build
requires Quartus 16.1.2.
