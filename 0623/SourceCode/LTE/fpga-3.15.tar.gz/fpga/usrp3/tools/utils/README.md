Packaging FPGA (and other) images
=================================

Run `package_images.py` from the directory where the images are stored.
