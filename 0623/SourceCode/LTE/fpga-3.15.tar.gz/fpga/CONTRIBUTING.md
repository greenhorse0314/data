# Contributing to UHD/FPGA

Please refer to the [UHD contribution guidelines](https://github.com/EttusResearch/uhd/blob/master/CONTRIBUTING.md),
they also apply to this repository.
Please note that the issue tracker for this repository has been disabled,
issues regarding the FPGA codebase can be reported on the
[UHD issue tracker](https://github.com/EttusResearch/uhd/issues).

