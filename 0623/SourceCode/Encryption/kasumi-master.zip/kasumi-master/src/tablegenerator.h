#ifndef __TABLEGENERATOR_H__
#define __TABLEGENERATOR_H__

void tableGenerator64(uint32_t * text);

#endif //TABLEGENERATOR_H
