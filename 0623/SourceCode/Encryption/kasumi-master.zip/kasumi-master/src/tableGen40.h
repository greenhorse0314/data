#ifndef __TABLEGENERATOR40_H__
#define __TABLEGENERATOR40_H__

void tableGenerator40(uint32_t * text);

#endif //TABLEGENERATOR32_H
