#ifndef __TABLEGENERATOR32_H__
#define __TABLEGENERATOR32_H__

void tableGenerator32(uint32_t * text);

#endif //TABLEGENERATOR32_H
