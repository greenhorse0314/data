To update the firmware on an NVR HI3536D, you will need to follow these steps:

1. First, you need to obtain the latest firmware for your NVR HI3536D. You can usually find this on the manufacturer's website or by contacting their support team.

2. Next, you need to copy the firmware file to a USB flash drive. Make sure that the flash drive is formatted with the FAT32 file system.

3. Insert the USB flash drive into one of the USB ports on the NVR HI3536D.

4. Log in to the NVR using the administrator account.

5. Open the Main Menu, and then click on System.

6. Click on Upgrade.

7. Click on the Browse button and select the firmware file from the USB flash drive.

8. Click on Upgrade.

9. The NVR will reboot and begin the firmware upgrade process. This may take several minutes.

10. Once the upgrade process is complete, log back in to the NVR to verify that the firmware has been updated successfully.

It is important to note that firmware updates can sometimes cause issues, so it is recommended to take a backup of your current configuration before performing the update.